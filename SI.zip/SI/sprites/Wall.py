#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

class Wall():
    def __init__(self):
        self.t = 0